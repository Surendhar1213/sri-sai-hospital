import './dist/server.js';
